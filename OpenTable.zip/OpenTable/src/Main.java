import java.util.Scanner;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        String items;
        int numbOfA = 0;
        int numbOfB = 0;
        int invalidSelection = 0;
        int total = 0;

        try (Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter list of items: ");

            items = scanner.nextLine().toUpperCase();
        }

        for (int i =0; i < items.length(); i++){
            if (items.charAt(i) == 'A') {
                numbOfA++;
                total += 50;
            }
            else if (items.charAt(i) == 'B'){
                numbOfB++;
                total += 30;
            }
            else if (items.charAt(i) == 'C'){
                total += 20;
            }
            else if (items.charAt(i) == 'D'){
                total += 10;
            }
            else {
                invalidSelection++;
            }
        }

        if (numbOfA >= 3){
            int itemADiscount = numbOfA / 3;
            total = total - (itemADiscount*20);
        }

        if (numbOfB >= 2) {
            int itemBDiscount = numbOfB / 2;
            total = total - (itemBDiscount*23);
        }

        if (invalidSelection == 0) {
            System.out.println("Total price: " + total);
        }
        else{
            System.out.println(invalidSelection + " valid selections have been made. These have been not been included " +
                    "in the price" + "\n" +
                    "Total price: " + total);
        }


    }
}
